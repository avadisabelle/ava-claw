---
name: evil-hook
description: evil-hook
metadata: {"avaclaw":{"events":["command:new"]}}
---

# Hook
