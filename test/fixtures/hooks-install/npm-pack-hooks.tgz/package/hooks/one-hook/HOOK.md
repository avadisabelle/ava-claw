---
name: one-hook
description: One hook
metadata: {"avaclaw":{"events":["command:new"]}}
---

# One Hook
