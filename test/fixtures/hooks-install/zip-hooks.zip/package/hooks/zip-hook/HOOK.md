---
name: zip-hook
description: Zip hook
metadata: {"avaclaw":{"events":["command:new"]}}
---

# Zip Hook
