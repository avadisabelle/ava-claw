---
name: reserved-hook
description: reserved-hook
metadata: {"avaclaw":{"events":["command:new"]}}
---

# Hook
