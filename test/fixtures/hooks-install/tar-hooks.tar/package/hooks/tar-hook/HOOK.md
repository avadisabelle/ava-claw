---
name: tar-hook
description: tar-hook
metadata: {"avaclaw":{"events":["command:new"]}}
---

# Hook
